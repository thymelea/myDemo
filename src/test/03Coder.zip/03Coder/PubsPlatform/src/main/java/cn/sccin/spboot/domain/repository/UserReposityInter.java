package cn.sccin.spboot.domain.repository;

import cn.sccin.spboot.domain.User;
import cn.sccin.spboot.domain.specific.UserDao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

/**
 * Created by developer_hyaci on 2015/9/25.
 */
public interface UserReposityInter extends JpaRepository<User,String>,UserDao,JpaSpecificationExecutor {
    User findByLoginame(String loginName);

    @Modifying
    @Query("update User u set u.failnum = 0 where u.failnum = 99")
    void initUserLoginStateAtStartUp();




    /*@Query("select u FROM SysUser u where u.fusername like :username ")
    Page<SysUser> queryPage(Pageable pageable,@Param("username")String username);*/
}
