package cn.sccin.spboot.security;

import cn.sccin.spboot.domain.User;
import cn.sccin.spboot.service.LogsService;
import cn.sccin.spboot.service.UserService;
import cn.sccin.spboot.utils.Statements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;

/**
 * 登陆成功之后的一些相关处理
 * @author developer_hyaci
 *
 */
@Component
public class LoginSuccessHandler extends SavedRequestAwareAuthenticationSuccessHandler {
	@Autowired
	private LoginUserDetailsService userService;

	@Autowired
	private LogsService logService;

	@Override
	public void onAuthenticationSuccess(HttpServletRequest request,
			HttpServletResponse response, Authentication authentication)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//示列代码如何实现自定SQL编写；
		userService.testDefineSql();




		//登陆成功,给用户附加当前登陆时间并更新当前用户（在用户验证过程中，对用户存在信息补全），
		SecurityUser securityUser =(SecurityUser)authentication.getPrincipal();
		User user=securityUser.getLoginUser();

		//维护当前登陆用户的权限；
		securityUser.setAuths(userService.getLoginUserAuths(user.getId()));
		//维护用户的登陆状态
		user.setLogtime(Timestamp.valueOf(LocalDateTime.now()));
		user.setFailnum(99);
		userService.modifyUser(user);
		Statements.addLoginSessionMap(user.getId(),request.getSession());
		//记录登陆成功日志
		logService.logInfo(this.getClass(),0,user.getLoginame(),"","","",user.getName()+"登陆成功",user.getName()+"登陆成功",true);

		this.setDefaultTargetUrl("/loginSuccess.html");
		this.setAlwaysUseDefaultTargetUrl(true);
		super.onAuthenticationSuccess(request, response, authentication);
	}

	
}
