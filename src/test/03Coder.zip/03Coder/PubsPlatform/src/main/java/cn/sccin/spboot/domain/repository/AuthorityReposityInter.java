package cn.sccin.spboot.domain.repository;

import cn.sccin.spboot.domain.Authority;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;

public interface AuthorityReposityInter extends JpaRepository<Authority,String>, JpaSpecificationExecutor<Authority> {
    @Query("SELECT a FROM  Authority a WHERE  a.parent = '' ORDER BY a.type ")
    List<Authority> findRootAuthoriys();

    List<Authority> findByParentIn(Collection<String> parents);

    @Query("SELECT distinct(a) FROM Userrole ur,Role r,Roleauths ra,Authority a,User u " +
            "WHERE u.id=ur.ruserid AND ur.rroleid=r.id and ra.rroleid=r.id and ra.rauthorityid=a.id " +
            "AND ur.ruserid = :userId " +
            "order by a.index ")
    List<Authority> getUserAhthoritys(@Param("userId")String userId);
}
