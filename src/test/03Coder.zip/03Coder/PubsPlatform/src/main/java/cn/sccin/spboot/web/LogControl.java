package cn.sccin.spboot.web;

import cn.sccin.spboot.domain.Nlog;
import cn.sccin.spboot.service.LogsService;
import cn.sccin.spboot.web.pojo.AjaxReturnBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by YF-Zhangbo on 2017/10/17.
 */
@Controller
@RequestMapping("/log")
public class LogControl extends GlobalExcaptionHolder{
    @Autowired
    private LogsService logsService;

    @RequestMapping(value = "/paramsLogs.html")
    public String searchPageLogs(@PageableDefault(value = PAGESIZE) Pageable pageable,@Param("fmessage") String fmessage,Model model) {
        Sort sort = new Sort(Sort.Direction.DESC, "time");
        pageable = new PageRequest(pageable.getPageNumber(), pageable.getPageSize(), sort);
        Page<Nlog> logsPoerPage=logsService.queryPageLogsByParams(fmessage,pageable);
        model.addAttribute("page",pageable.getPageNumber()+1);
        model.addAttribute("total",logsPoerPage.getTotalPages());
        model.addAttribute("logs",logsPoerPage.getContent());

        model.addAttribute("fmessage",fmessage);
        return "log/sysRunLogs";
    }
    @RequestMapping(value = "/detailLogs")
    public @ResponseBody
    AjaxReturnBean detailLogs(@Param("fid") String fid,Model model,HttpServletRequest request) {
        List<Map<String,String>> listLogs = new ArrayList<Map<String,String>>();
        String msg = "";
        boolean fidFlag = fid != null && !fid.trim().equals("");
        if (fidFlag) {
            Nlog logs = logsService.detailLog(fid);
            Map<String,String> mapLogs = new HashMap<String,String>();
            mapLogs.put("ftime", logs.getTime().toString().substring(0, logs.getTime().toString().lastIndexOf(".")));
            mapLogs.put("ftype", logs.getType()+"");
            mapLogs.put("farg0", logs.getArg0());
            mapLogs.put("farg1", logs.getArg1());
            mapLogs.put("farg2", logs.getArg2());
            mapLogs.put("farg3", logs.getArg3());
            mapLogs.put("fmessage", logs.getArg4());
            mapLogs.put("fdescribe", logs.getRemark());
            listLogs.add(mapLogs);
        } else {
            return AjaxReturnBean.createError("请求唯一标识传递失败", null);
        }
        return AjaxReturnBean.createSuccess("success",listLogs);
    }
    @RequestMapping(value = "/deleteLogsByFid")
    public @ResponseBody AjaxReturnBean  deleteLog(@Param("fid") String fid,Model model,HttpServletRequest request){

        boolean fidFlag = fid != null && !fid.trim().equals("");
        if(fidFlag){
            try {
                logsService.delectLogByFid(fid);
                return  AjaxReturnBean.createSuccess("删除日志成功",null);
            } catch (Exception e) {
                return  AjaxReturnBean.createError("删除日志失败", e.toString());
            }
        } else {
            return  AjaxReturnBean.createError("请求唯一标识传递失败", null);
        }

    }
}
