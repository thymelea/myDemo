package cn.sccin.spboot.domain;

import javax.persistence.*;

/**
 * Created by developer_hyaci on 2017/10/11.
 */
@Entity
@Table(name = "rnroleauths", schema = "")
public class Roleauths {
    private String id;
    private String rroleid;
    private String crolecode;
    private String rauthorityid;


    //冗余字段
    private String name;//角色名称


    public Roleauths(){}

    public Roleauths(String rroleid,String crolecode,String name){
        this.rroleid = rroleid;
        this.crolecode = crolecode;
        this.name = name;
    }
    @Transient
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Id
    @Column(name = "fid", nullable = false, insertable = true, updatable = true, length = 50)
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Basic
    @Column(name = "rroleid", nullable = true, insertable = true, updatable = true, length = 50)
    public String getRroleid() {
        return rroleid;
    }

    public void setRroleid(String rroleid) {
        this.rroleid = rroleid;
    }

    @Basic
    @Column(name = "crolecode", nullable = true, insertable = true, updatable = true, length = 50)
    public String getCrolecode() {
        return crolecode;
    }

    public void setCrolecode(String crolecode) {
        this.crolecode = crolecode;
    }

    @Basic
    @Column(name = "rauthorityid", nullable = true, insertable = true, updatable = true, length = 50)
    public String getRauthorityid() {
        return rauthorityid;
    }

    public void setRauthorityid(String rauthorityid) {
        this.rauthorityid = rauthorityid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Roleauths roleauths = (Roleauths) o;

        if (id != null ? !id.equals(roleauths.id) : roleauths.id != null) return false;
        if (rroleid != null ? !rroleid.equals(roleauths.rroleid) : roleauths.rroleid != null) return false;
        if (crolecode != null ? !crolecode.equals(roleauths.crolecode) : roleauths.crolecode != null) return false;
        if (rauthorityid != null ? !rauthorityid.equals(roleauths.rauthorityid) : roleauths.rauthorityid != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (rroleid != null ? rroleid.hashCode() : 0);
        result = 31 * result + (crolecode != null ? crolecode.hashCode() : 0);
        result = 31 * result + (rauthorityid != null ? rauthorityid.hashCode() : 0);
        return result;
    }
}
