package cn.sccin.spboot.domain;

import javax.persistence.*;

/**
 * Created by developer_hyaci on 2017/10/11.
 */
@Entity
@Table(name = "rnfiledepend", schema = "")
public class Filedepend {
    private String id;
    private String quoteunique;
    private Integer quotetype;
    private String rfileinfoid;

    @Id
    @Column(name = "fid", nullable = false, insertable = true, updatable = true, length = 50)
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Basic
    @Column(name = "fquoteunique", nullable = true, insertable = true, updatable = true, length = 50)
    public String getQuoteunique() {
        return quoteunique;
    }

    public void setQuoteunique(String quoteunique) {
        this.quoteunique = quoteunique;
    }

    @Basic
    @Column(name = "fquotetype", nullable = true, insertable = true, updatable = true)
    public Integer getQuotetype() {
        return quotetype;
    }

    public void setQuotetype(Integer quotetype) {
        this.quotetype = quotetype;
    }

    @Basic
    @Column(name = "rfileinfoid", nullable = true, insertable = true, updatable = true, length = 50)
    public String getRfileinfoid() {
        return rfileinfoid;
    }

    public void setRfileinfoid(String rfileinfoid) {
        this.rfileinfoid = rfileinfoid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Filedepend that = (Filedepend) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (quoteunique != null ? !quoteunique.equals(that.quoteunique) : that.quoteunique != null) return false;
        if (quotetype != null ? !quotetype.equals(that.quotetype) : that.quotetype != null) return false;
        if (rfileinfoid != null ? !rfileinfoid.equals(that.rfileinfoid) : that.rfileinfoid != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (quoteunique != null ? quoteunique.hashCode() : 0);
        result = 31 * result + (quotetype != null ? quotetype.hashCode() : 0);
        result = 31 * result + (rfileinfoid != null ? rfileinfoid.hashCode() : 0);
        return result;
    }
}
