package cn.sccin.spboot;

import cn.sccin.spboot.config.StartupListener;
import cn.sccin.spboot.config.SysConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

@EnableWebSecurity
@SpringBootApplication
@EnableConfigurationProperties({SysConfig.class})
@EnableScheduling
public class SecurityJpamvcThymeleafBaseSpringBootApplication {

    public static void main(String[] args) {
        SpringApplication springApp=new SpringApplication(SecurityJpamvcThymeleafBaseSpringBootApplication.class);
        springApp.addListeners(new StartupListener());
        springApp.run(args);
    }
}
