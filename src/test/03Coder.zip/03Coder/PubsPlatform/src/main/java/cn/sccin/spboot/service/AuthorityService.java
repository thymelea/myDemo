package cn.sccin.spboot.service;

import cn.sccin.spboot.domain.Authority;
import cn.sccin.spboot.domain.Roleauths;
import cn.sccin.spboot.domain.repository.AuthorityReposityInter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component("authorityService")
public class AuthorityService {
    @Autowired
    private AuthorityReposityInter authortiyInter;

    /**获取本系统支持的所有权限
     * 返回值中第0个为第1层权限，第1个为第2层权限以此类推；
     * */
    public List<List<Authority>>  getAutoritys(){
        List<List<Authority>> returnList=new ArrayList<>();
        List<Authority> authList= authortiyInter.findRootAuthoriys();
        if(authList!=null && authList.size()!=0){
            returnList.add(authList);
            List<String> ids=authList.stream().map(authortiy -> authortiy.getId()).collect(Collectors.toList());
            this.handleSubAutority(ids,returnList);
        }
        return returnList;
    }

    private void handleSubAutority(List<String> parents,List<List<Authority>> authortiys){
        List<Authority> tempList_authortiys=authortiyInter.findByParentIn(parents);
        if(tempList_authortiys!=null && tempList_authortiys.size() !=0){
            authortiys.add(tempList_authortiys);
            List<String> ids=tempList_authortiys.stream().map(authortiy -> authortiy.getId()).collect(Collectors.toList());
            this.handleSubAutority(ids,authortiys);
        }
    }


    /**
     * 将权限转为前台界面所需的数据格式
     * */
    public List<Map<String,Object>> changToListMap(List<List<Authority>> authortiys, List<Roleauths> rpList){
        List<Map<String,Object>> returnList=new ArrayList<>();
        if(authortiys!=null && authortiys.size()!=0){
            //用于存放循环过程中父节点与其所有子节点的关系。
            Map<String,Object> tempMap=new HashMap<>();
            //用户存放内循环中具体的循环变量
            List<Authority> authList_temp =null;
            //循环变量中的个体
            Authority beanTemp=null;
            //循环变量的个体转为的MAP的存放
            Map<String,Object> beanMap=null;
            //用于存放所有的同父类的子类
            List<Map<String,Object>> tempMapList=null;
            for (int i=authortiys.size()-1;i<authortiys.size()&&i>=0;i--){
                authList_temp=authortiys.get(i);
                for(int j=0;j<authList_temp.size();j++){
                    beanTemp=authList_temp.get(j);
                    beanMap=authortiyToMap(beanTemp,rpList);
                    if(tempMap.containsKey(beanTemp.getId())){
                        List<Map<String,Object>> sublist=(List<Map<String,Object>>)tempMap.get(beanTemp.getId());
                        sublist=sublist.stream().sorted((map1,map2) ->{
                            return ((Integer)map1.get("index")).compareTo((Integer) map2.get("index"));
                        }).collect(Collectors.toList());
                        ((List<Map<String,Object>>)beanMap.get("subAuList")).addAll(sublist);
                    }
                    if(beanTemp.getParent().equals("")){
                        returnList.add(beanMap);
                    }else{
                        if(!tempMap.containsKey(beanTemp.getParent())){
                            tempMapList=new ArrayList<>();
                            tempMapList.add(beanMap);
                            tempMap.put(beanTemp.getParent(), tempMapList);
                        }else{
                            ((List<Map<String,Object>>)tempMap.get(beanTemp.getParent())).add(beanMap);
                        }
                    }
                }
            }
        }
        return returnList;
    };


    /**将权限转为MAP并判定该权限是否已经被授权
     * */
    private Map<String,Object> authortiyToMap(Authority authortiy,List<Roleauths> rpList){
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("auId", authortiy.getId());
        map.put("auName", authortiy.getName());
        map.put("auDescrible", authortiy.getRemark());
        map.put("auType",authortiy.getType());
        map.put("index",authortiy.getIndex());
        map.put("url",authortiy.getUrl());
        map.put("checked", "0");
        map.put("subAuList",new ArrayList<Map<String,Object>>());
        long flag = rpList.stream().filter(rolepower -> {
            if (rolepower.getRauthorityid().equals(authortiy.getId())) {
                return true;
            } else {
                return false;
            }
        }).count();
        if (flag != 0) {
            map.put("checked", "1");
        }
        return map;
    }
}
