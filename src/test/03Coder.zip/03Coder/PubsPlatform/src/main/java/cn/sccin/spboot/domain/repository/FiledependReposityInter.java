package cn.sccin.spboot.domain.repository;

import cn.sccin.spboot.domain.Filedepend;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface FiledependReposityInter extends JpaRepository<Filedepend,String>,JpaSpecificationExecutor<Filedepend>{

    List<Filedepend> findByRfileinfoidIn(@Param("fileInfoFids") List<String> fileInfoFids);
}
