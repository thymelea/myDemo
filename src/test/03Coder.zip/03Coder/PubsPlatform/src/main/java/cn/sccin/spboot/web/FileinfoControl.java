package cn.sccin.spboot.web;

import cn.sccin.spboot.domain.Fileinfo;
import cn.sccin.spboot.service.FileinfoService;
import cn.sccin.spboot.utils.Utility;
import cn.sccin.spboot.web.pojo.AjaxReturnBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.query.Param;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Controller
@RequestMapping("/fileInfo/")
public class FileinfoControl {

    private static Logger logger = LoggerFactory.getLogger(FileinfoControl.class);

    @Autowired
    private FileinfoService fileinfoService;

    @RequestMapping("listPage.html")
    public String getFileInfoList(@PageableDefault Pageable pageable, Model model, @Param("name") String name, @Param("storename") String storename,
                                  @Param("suffix") String suffix, @Param("stime") String stime, @Param("etime") String etime){
        Utility.TimeFomat timeFomat = Utility.TimeFomat.DATETIMEFOMAT;
        //参数构建
        HashMap<String,Object> paramMap = new HashMap<>();
        paramMap.put("name",name);
        paramMap.put("storename",storename);
        paramMap.put("suffix",suffix);
        paramMap.put("stime", Utility.checkTimeFomat(stime,timeFomat)?
                Timestamp.valueOf(LocalDateTime.parse(stime,DateTimeFormatter.ofPattern(timeFomat.valueOf()))):null);
        paramMap.put("etime",Utility.checkTimeFomat(etime,timeFomat)?
                Timestamp.valueOf(LocalDateTime.parse(etime,DateTimeFormatter.ofPattern(timeFomat.valueOf()))):null);
        //分页查询
        Page<Fileinfo> page = fileinfoService.findFileinfoByPage(pageable.previousOrFirst(),paramMap);
        paramMap.put("stime",stime);
        paramMap.put("etime",etime);
        model.addAttribute("fileInfos",page.getContent());
        model.addAttribute("page",page.getNumber()+1);
        model.addAttribute("total",page.getTotalPages());
        model.addAttribute("paramMap",paramMap);
        return "fileInfo/fileInfoList";
    }

    @RequestMapping("del")
    @ResponseBody
    public AjaxReturnBean delFileInfo(@Param("fids") String fids){
        List<String> list = null;
        if(!StringUtils.isEmpty(fids)){
            if(fids.contains(",")){
                list = Arrays.asList(fids.split(","));
            }else{
                list = new ArrayList<>();
                list.add(fids);
            }
        }
        if(fids != null){
             return fileinfoService.delFileinfo(list);
        }
        return AjaxReturnBean.createError("无效请求",null);
    }

    @RequestMapping("edit/{fid}.html")
    public String editFileInfo(@PathVariable("fid") String fid,Model model){
        model.addAttribute("fileInfo",fileinfoService.findByFid(fid));
        return "fileInfo/fileInfoEdit";
    }

    @RequestMapping("save")
    @ResponseBody
    public AjaxReturnBean saveOrUpdateFileInfo(Fileinfo fileinfo){
        return fileinfoService.saveOrUpdateFileInfo(fileinfo);
    }
}
