package cn.sccin.spboot.web;

import cn.sccin.spboot.domain.Authority;
import cn.sccin.spboot.domain.User;
import cn.sccin.spboot.security.DefineAuthItem;
import cn.sccin.spboot.service.UserService;
import cn.sccin.spboot.utils.Statements;
import cn.sccin.spboot.web.pojo.AjaxReturnBean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by developer_hyaci on 2015/10/23.
 */
@Controller
public class HtmlControl extends GlobalExcaptionHolder{


    @RequestMapping("/")
    public String home(HttpServletResponse response,HttpServletRequest request) {
        //系统根目录访问跳转，进入首页
        User user = UserService.getUserFromSession(request);
//        if(user!=null && user.getUserGroupIds()!=null && user.getUserGroupIds().indexOf("31cc0761-b710-4190-93b8-b3119c2054c8")!=-1){
//            //管理员组
//            return "redirect:/back.html";
//        }
//        else if(user!=null && user.getUserGroupIds()!=null && user.getUserGroupIds().indexOf("93431bf0-e036-41e0-80fd-ef417670d479")!=-1){
//            //会员组
//            return "redirect:/frontBack.html";
//        }else if (user!=null && user.getUserGroupIds()!=null && user.getUserGroupIds().indexOf("0da7373d-45bc-458d-a50e-cb8e0ca2219d")!=-1){
//            //普通用户组
//            return "redirect:/frontBack.html";
//        }
        if(user!=null){
            return "redirect:/back.html";
        }
        return "redirect:/index.html";
    }

    @RequestMapping(value={"/index.html"})
    public String index(HttpServletResponse response,HttpServletRequest request, Model model) {
        //首页访问页面
        return "login";
    }

    @RequestMapping(value={"/back.html"})
    public String backIndex(HttpServletResponse response,HttpServletRequest request, Model model) {
        //访问后台管理页面
        //从当前登陆用户的权限中获取后台的权限
        List<DefineAuthItem> allAuths=UserService.getUserAuthsTreeFromSession(request);
        List<DefineAuthItem> backAuth=new ArrayList<>();

        for(int i=0;i<allAuths.size();i++){
            //url 为0，type为表示后台顶级菜单
            if(allAuths.get(i).getAuthorityBean().getUrl().equals("0") &&
                    allAuths.get(i).getAuthorityBean().getType().intValue()==1){
                backAuth.add(allAuths.get(i));
            }
        }
        request.getSession().setAttribute("uathsBack",backAuth.size()!=0?backAuth:null);

        return "home";
    }
    @RequestMapping(value={"/frontBack.html"},method= RequestMethod.POST)
    public String frontBackIndex(HttpServletResponse response,HttpServletRequest request, Model model) {
        //执行具体子页面跳转的导航id
        String jumpId = request.getParameter("target");
        model.addAttribute("target","");
        if(!StringUtils.isEmpty(jumpId)){
            model.addAttribute("target",jumpId);
        }
        //前台管理页面
        return "frontBackIndex";
    }

    @RequestMapping(value = { "/pub/sqlblind.html" })
    public String sqlblind() {
        return "sqlblindMsg";
    }
    @RequestMapping(value = { "/error.html" })
    public String error() {
        return "error";
    }

    @RequestMapping(value = { "/ajaxNoAuth" })
    public @ResponseBody AjaxReturnBean ajaxNoAuth(){
        return AjaxReturnBean.createError("不具有权限",null);
    }

}
