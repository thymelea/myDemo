package cn.sccin.spboot.domain.specific;

import cn.sccin.spboot.domain.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Map;

/**
 * Created by developer_hyaci on 2017/4/10.
 */
public interface UserDao {
    /*Page<SysUser> search(Map<String, String> params);*/

    /**
     * 根据制单号集合获取与TWS交流获取退款信息的集合；
     * refunds 最大长度为100，超过或者为null时根据制单号返回前100条数据
     * 约定Map的格式为：
     *  refundNo：
     *  fpbucode：
     *  orderNo：
     * */
    List<Map<String,String>> getRefundInfos(List<String> refunds);

    Page<User> queryUserList(String userName, Pageable pageable);

    User findUserById(String userId);

    List<User> getUserByParams(String userName,String uerloginName);

    Map<String,String> queryRoleNames(List<String> userIdList);
}
