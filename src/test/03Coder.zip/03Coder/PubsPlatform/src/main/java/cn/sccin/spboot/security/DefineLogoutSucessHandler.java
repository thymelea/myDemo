package cn.sccin.spboot.security;

import cn.sccin.spboot.domain.User;
import cn.sccin.spboot.service.LogsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.security.web.authentication.logout.SimpleUrlLogoutSuccessHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;

/**
 * Created by developer_hyaci on 2017/10/17.
 */
@Component
public class DefineLogoutSucessHandler extends SimpleUrlLogoutSuccessHandler {

    public static final String NORMALSESSIONCLOSE="logout_sessionClose_flag";

    @Override
    public void onLogoutSuccess(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Authentication authentication) throws IOException, ServletException {
        this.setDefaultTargetUrl("/login?logout");
        this.setAlwaysUseDefaultTargetUrl(true);

        //在session过期的监听器中实现
        // 往session中存入是正常退出session过期还是session默认过期
        httpServletRequest.getSession().setAttribute(NORMALSESSIONCLOSE,true);

        super.onLogoutSuccess(httpServletRequest, httpServletResponse, authentication);

    }
}
