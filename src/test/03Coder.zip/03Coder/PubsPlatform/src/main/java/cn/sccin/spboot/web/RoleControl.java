package cn.sccin.spboot.web;


import cn.sccin.spboot.domain.Role;
import cn.sccin.spboot.domain.Roleauths;
import cn.sccin.spboot.domain.Userrole;
import cn.sccin.spboot.domain.repository.UserRoleReposityInter;
import cn.sccin.spboot.service.RoleService;
import cn.sccin.spboot.service.RoleauthsService;
import cn.sccin.spboot.web.pojo.AjaxReturnBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.query.Param;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.*;

@Controller
public class RoleControl extends GlobalExcaptionHolder{
    @Autowired
    private RoleService roleService;
    @Autowired
    private RoleauthsService roleauthsService;


    /**
     * 显示当前有那些角色
     */
    @RequestMapping("/role/paramsRole.html")
    public String searchPageRole(@PageableDefault(value = PAGESIZE) Pageable pageable,@Param("frole") String frole, Model model) {
        //根据角色Code获取角色
        Page<Role> roles = roleService.findRole(frole,pageable);

        if(roles == null || roles.getContent().size() == 0){
            model.addAttribute("roles","");
        }else{
            model.addAttribute("roles",roles.getContent());
        }

        model.addAttribute("page",pageable.getPageNumber()+1);
        model.addAttribute("total",roles.getTotalPages());
        model.addAttribute("frole",frole);
        return "role/roleList";
    }


    /**
     * 添加或修改角色
     * @param fid       角色唯一标识
     * @param roleName  角色名称
     * @param roleCode  角色code
     * @param request
     * @return
     */
    @RequestMapping("/role/addRole")
    public @ResponseBody AjaxReturnBean addRole(@Param("fid") String fid,@Param("roleName") String roleName, @Param("roleCode") String roleCode, HttpServletRequest request){
       // Map<String, String> returnMap = new HashMap<String, String>();
        boolean rolenameFlag = roleName != null && !roleName.trim().equals("");
        boolean roleCodeFlag = roleCode != null && !roleCode.trim().equals("");
        boolean fidFlag = fid != null && !fid.trim().equals("");

        Role role = new Role();
        if(rolenameFlag && roleCodeFlag){
            if(fidFlag){
                //角色修改（角色编码禁止修改）
                Role tmpRole = roleService.findByFid(fid);
                if (!roleCode.equals(tmpRole.getCode())) {
                    //returnMap.put("msg","角色编码是唯一存在项，禁止修改");
                    return AjaxReturnBean.createError("角色编码是唯一存在项，禁止修改",null);
                }
            }else{
                //判断该角色是否已经存在
                Role tmpRole = roleService.findByRoleCode(roleCode);
                if(tmpRole != null){
                    //returnMap.put("msg","角色编码是唯一存在项，该角色编码已经存在，请确认后重新添加");
                    return AjaxReturnBean.createError("角色编码是唯一存在项，该角色编码已经存在，请确认后重新添加",null);
                }
            }
            role.setCode(roleCode);
            role.setName(roleName);
            role.setTime(Timestamp.valueOf(LocalDateTime.now()));
        }else{
            //returnMap.put("msg","存在必填项为空，请填写后重新添加");
            return AjaxReturnBean.createError("存在必填项为空，请填写后重新添加",null);
        }

        if(fidFlag){
            role.setId(fid);
        }else{
            role.setId(UUID.randomUUID().toString());
        }
        AjaxReturnBean result=null;
        String returnMsg = "";
        //保存数据,添加try catch捕捉数据保存异常
        try{
            roleService.saveRole(role);
            returnMsg = "success";
            result=AjaxReturnBean.createSuccess(returnMsg,null);
        }catch (Exception e){
            if(fidFlag){
                returnMsg = "修改角色失败，请重试";
            }else{
                returnMsg = "添加角色失败，请重试";
            }
            result=AjaxReturnBean.createError(returnMsg,null);
        }

        return result;
    }

    /**
     * 删除角色
     * @param fid      角色唯一标识
     * @param request
     * @return
     */
    @RequestMapping("/role/deleteRole")
    public @ResponseBody AjaxReturnBean delRole(@Param("fid") String fid,HttpServletRequest request){
       // Map<String, String> returnMap = new HashMap<String, String>();
        boolean fidFlag = fid != null && !fid.trim().equals("");
        AjaxReturnBean result=null;
        String returnMsg = "";
        if(fidFlag){
            //获取要删除的对象
            Role tmpRole = roleService.findByFid(fid);
            //判断该角色是否能够删除
            if(tmpRole.getCode().equals("admin")){
                //returnMap.put("msg","管理员角色不能被删除");
                return AjaxReturnBean.createError("管理员角色不能被删除",null);
            }

            //判断该角色是否已经绑定用户
            List<Userrole> userrole = roleService.findUserroleByRoleId(fid);
            if( userrole.size()>0 && userrole != null ){
                //returnMap.put("msg","该角色已被用户使用,请先解除与用户之间的关系后再删除");
                return AjaxReturnBean.createError("该角色已被用户使用,请先解除与用户之间的关系后再删除",null);
            }
            //判断角色是否有权限，有权限应先删除权限
            List<Roleauths> lstRoleauths = roleauthsService.findByRoleIdAndRoleCode(tmpRole.getId(),tmpRole.getCode());
            if( lstRoleauths.size()>0 && lstRoleauths != null ){
               // returnMap.put("msg","该角色已被赋予权限,请先解除该角色的权限后再删除");
                return AjaxReturnBean.createError("该角色已被赋予权限,请先解除该角色的权限后再删除",null);
            }
            //删除角色
            try{
                roleService.deleteRole(tmpRole);
                returnMsg = "success";
                result=AjaxReturnBean.createSuccess(returnMsg,null);
            }catch (Exception e){
                returnMsg = "角色删除失败";
                result=AjaxReturnBean.createError(returnMsg,null);
            }

        }else{
            returnMsg = "未传递唯一标识";
            result=AjaxReturnBean.createError(returnMsg,null);
        }
        //returnMap.put("msg",returnMsg);
        return result;
    }


    /**
     * 根据fid获取该fid对应的角色的信息
     * @param fid      角色唯一标识
     * @param request
     * @return
     */
    @RequestMapping("/role/detailRole")
    public @ResponseBody AjaxReturnBean detailRole(@Param("fid") String fid, HttpServletRequest request){
     //   Map<String, List> map = new HashMap<String, List>();
       //List<String> list = new ArrayList<String>();
       // List<Role> listRole = new ArrayList<Role>();
        AjaxReturnBean result=null;
        String returnMsg = "";
        if(fid != null && !fid.trim().equals("")){
            Role role = roleService.findByFid(fid);
            returnMsg = "success";
            result = AjaxReturnBean.createSuccess(returnMsg, role);
            // listRole.add(role);
        } else{
            returnMsg = "唯一标识未传递";
            result=AjaxReturnBean.createError(returnMsg,null);
        }
       // list.add(returnMsg);
       // map.put("msg", list);
       // map.put("role", listRole);
        return result;
    }
}
