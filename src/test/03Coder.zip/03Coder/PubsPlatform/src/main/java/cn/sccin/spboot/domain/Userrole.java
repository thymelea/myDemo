package cn.sccin.spboot.domain;

import javax.persistence.*;

/**
 * Created by developer_hyaci on 2017/10/11.
 */
@Entity
@Table(name = "rnuserrole", schema = "")
public class Userrole {
    private String id;
    private String ruserid;
    private String rroleid;
    private String crolecode;

    @Id
    @Column(name = "fid", nullable = false, insertable = true, updatable = true, length = 50)
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Basic
    @Column(name = "ruserid", nullable = true, insertable = true, updatable = true, length = 50)
    public String getRuserid() {
        return ruserid;
    }

    public void setRuserid(String ruserid) {
        this.ruserid = ruserid;
    }

    @Basic
    @Column(name = "rroleid", nullable = true, insertable = true, updatable = true, length = 50)
    public String getRroleid() {
        return rroleid;
    }

    public void setRroleid(String rroleid) {
        this.rroleid = rroleid;
    }

    @Basic
    @Column(name = "crolecode", nullable = true, insertable = true, updatable = true, length = 50)
    public String getCrolecode() {
        return crolecode;
    }

    public void setCrolecode(String crolecode) {
        this.crolecode = crolecode;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Userrole userrole = (Userrole) o;

        if (id != null ? !id.equals(userrole.id) : userrole.id != null) return false;
        if (ruserid != null ? !ruserid.equals(userrole.ruserid) : userrole.ruserid != null) return false;
        if (rroleid != null ? !rroleid.equals(userrole.rroleid) : userrole.rroleid != null) return false;
        if (crolecode != null ? !crolecode.equals(userrole.crolecode) : userrole.crolecode != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (ruserid != null ? ruserid.hashCode() : 0);
        result = 31 * result + (rroleid != null ? rroleid.hashCode() : 0);
        result = 31 * result + (crolecode != null ? crolecode.hashCode() : 0);
        return result;
    }
}
