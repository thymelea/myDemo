package cn.sccin.spboot.config;

import cn.sccin.spboot.service.UserService;
import cn.sccin.spboot.utils.RSAUtils;
import cn.sccin.spboot.utils.Statements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by developer_hyaci on 2016/3/23.
 */
public class StartupListener implements ApplicationListener<ContextRefreshedEvent> {

    private final static Logger logger = LoggerFactory.getLogger(StartupListener.class);

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        logger.info("===================>>>Start some system codes that can be executing 。");
        //项目启动之后初始化一对RSA公私钥，用于处理前台UI往后台传输敏感数据时进行密文传输；
        try{
            HashMap mapRsa= RSAUtils.getKeys();
//          keys:modulus|public_exponent|publicKey|privateKey
            Statements.rsaPairs.put("publicKey",(RSAPublicKey) mapRsa.get("public"));
            Statements.rsaPairs.put("privateKey",(RSAPrivateKey) mapRsa.get("private"));
            Statements.rsaPairs.put("modulus", Statements.getRSAPubKey().getModulus().toString(16));
            Statements.rsaPairs.put("public_exponent",Statements.getRSAPubKey().getPublicExponent().toString(16));
            mapRsa=null;
        }catch (Exception e){
            logger.error("project creating！but the rsa pairs build a exception:"+e.getMessage());
            logger.error("system exit!!");
            System.exit(0);
        }

        //项目启动之后,将由于系统宕机导致用户没有退出的用户更正为退出状态；
        UserService userService=event.getApplicationContext().getBean(UserService.class);
        try {
            userService.initUserStateUseforStartUp();
        }catch (Exception e){
            logger.error("user loginState init！but there  build a exception:"+e.getMessage());
            logger.error("system exit!!");
            System.exit(0);
        }
        logger.info("===================>>>End some system codes that can be executing 。");
    }
}
