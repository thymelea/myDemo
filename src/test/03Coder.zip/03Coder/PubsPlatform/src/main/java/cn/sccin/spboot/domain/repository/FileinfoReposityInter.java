package cn.sccin.spboot.domain.repository;

import cn.sccin.spboot.domain.Fileinfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface FileinfoReposityInter extends JpaRepository<Fileinfo,String>,JpaSpecificationExecutor<Fileinfo>{

}
