package cn.sccin.spboot.security;

import cn.sccin.spboot.domain.Authority;
import cn.sccin.spboot.domain.User;
import cn.sccin.spboot.domain.repository.UserReposityInter;
import cn.sccin.spboot.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class LoginUserDetailsService implements UserDetailsService {
	@Autowired
	private UserReposityInter userReposity;
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	@Autowired
	private UserService userService;

	@Override
	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		User user=this.getUserByUsername(userName);
		if(user ==null){
			throw new UsernameNotFoundException("无法根据用户名获取信息。");
		}
		return new SecurityUser(user);
	}

	public User getUserByUsername(String userName){
		return userReposity.findByLoginame(userName);
	}
	public boolean verifyPasd(String encodePasd,String pasd){
		return passwordEncoder.matches(pasd,encodePasd);
	}

	public boolean verifyCADN(String dbCadn,String formCadn){
		//最初版本没有对CA进行响应的判定，默认成功；
		if(dbCadn!=null&&!dbCadn.trim().equals("")){
			if(formCadn!=null &&!formCadn.trim().equals("")){
				return dbCadn.equals(formCadn);
			}else{
				return false;
			}
		}
		return true;
	}
	public List<Authority> getLoginUserAuths(String userId){
		return userService.getUserAuths(userId);
	}


	//新增和更新用户信息；
	public void modifyUser(User user){
		userReposity.save(user);
	}
	

	public void testDefineSql(){
		String userName="";
		String loginName="a";
		this.userReposity.getUserByParams(userName,loginName);
	}

}
