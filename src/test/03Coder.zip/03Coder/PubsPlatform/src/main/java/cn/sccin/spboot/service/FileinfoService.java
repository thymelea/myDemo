package cn.sccin.spboot.service;

import cn.sccin.spboot.domain.Filedepend;
import cn.sccin.spboot.domain.Fileinfo;
import cn.sccin.spboot.domain.repository.FiledependReposityInter;
import cn.sccin.spboot.domain.repository.FileinfoReposityInter;
import cn.sccin.spboot.web.pojo.AjaxReturnBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.io.File;
import java.sql.Timestamp;
import java.util.*;

@Component("fileinfoService")
public class FileinfoService {

    @Autowired
    private FileinfoReposityInter fileinfoReposityInter;
    @Autowired
    private FiledependReposityInter filedependReposityInter;

    public Page<Fileinfo> findFileinfoByPage(Pageable pageable,HashMap<String, Object> paramMap){
        Specification<Fileinfo> specification = new Specification<Fileinfo>() {
            //参数列表
            Object name = paramMap.get("name");
            Object storename = paramMap.get("storename");
            Object suffix = paramMap.get("suffix");
            Object stime = paramMap.get("stime");
            Object etime = paramMap.get("etime");
            @Override
            public Predicate toPredicate(Root<Fileinfo> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
                List<Predicate> predicates = new ArrayList<>();
                if(name instanceof String && !StringUtils.isEmpty(name)){
                    predicates.add(criteriaBuilder.like(root.get("name").as(String.class),"%"+name+"%"));
                }
                if(storename instanceof String && !StringUtils.isEmpty(storename)){
                    predicates.add(criteriaBuilder.like(root.get("storename").as(String.class),"%"+storename+"%"));
                }
                if(suffix instanceof String && !StringUtils.isEmpty(suffix)){
                    predicates.add(criteriaBuilder.like(root.get("suffix").as(String.class),"%"+suffix+"%"));
                }
                if(stime instanceof Timestamp){
                    predicates.add(criteriaBuilder.greaterThanOrEqualTo(root.get("time").as(Timestamp.class),(Timestamp) stime));
                }
                if(etime instanceof Timestamp){
                    predicates.add(criteriaBuilder.lessThanOrEqualTo(root.get("time").as(Timestamp.class),(Timestamp) etime));
                }
                return criteriaQuery.where(predicates.toArray(new Predicate[predicates.size()])).getRestriction();
            }
        };
        return fileinfoReposityInter.findAll(specification,pageable);
    }

    /**
     *  删除fileinfo
     * @param fids  对应fid
     */
    public AjaxReturnBean delFileinfo(List<String> fids){
        //删除不存在关联关系的fid数据
        List<Filedepend> filedepends = filedependReposityInter.findByRfileinfoidIn(fids);
        List<String> ables = new ArrayList<>(fids);  //可删除缓存
        for(String fid:fids){
            for(Filedepend filedepend:filedepends){
                if(fid.equals(filedepend.getRfileinfoid())){
                    if(ables.contains(fid)) ables.remove(fid);
                }
            }
        }

        //删除后并删除文件
        List<Fileinfo> fileinfos = fileinfoReposityInter.findAll(ables);
        fileinfoReposityInter.deleteInBatch(fileinfoReposityInter.findAll(ables));
        File file = null;
        for(Fileinfo fileinfo:fileinfos){
            file = new File(fileinfo.getStoreplace()+fileinfo.getStorename()+(fileinfo.getSuffix().startsWith(".")?fileinfo.getSuffix():"."+fileinfo.getSuffix()));
            if(file.exists()&&file.isFile()){
                file.delete();
            }
        }
        if(ables.size() > 0){
            return AjaxReturnBean.createSuccess("删除文件信息成功",null);
        }
        return AjaxReturnBean.createError("该文件存在关联信息不可删除",null);
    }

    public Fileinfo findByFid(String fid){
        return fileinfoReposityInter.findOne(fid);
    }

    public AjaxReturnBean saveOrUpdateFileInfo(Fileinfo fileinfo){
        //通用参数校验
        if(StringUtils.isEmpty(fileinfo.getName()) || StringUtils.isEmpty(fileinfo.getStorename())
                || fileinfo.getTime() == null){
            return AjaxReturnBean.createError("参数校验失败，文件名、储存名、时间不可为空",null);
        }
        //新增
        if(StringUtils.isEmpty(fileinfo.getId())) {
            if(StringUtils.isEmpty(fileinfo.getStoreplace())||StringUtils.isEmpty(fileinfo.getSuffix())){
                return AjaxReturnBean.createError("参数校验失败，储存地址、后缀名不可为空",null);
            }
            fileinfo.setId(UUID.randomUUID().toString());
        //修改
        }else{
            Fileinfo sourceFileinfo = fileinfoReposityInter.findOne(fileinfo.getId());
            if(sourceFileinfo == null){
                return AjaxReturnBean.createError("文件ID查找失败",null);
            }
            List<Filedepend> depends = filedependReposityInter.findByRfileinfoidIn(Arrays.asList(new String[]{sourceFileinfo.getId()}));
            if(depends.size() > 0){
                //存在关联的不可修改地址及后缀
                fileinfo.setStoreplace(sourceFileinfo.getStoreplace());
                fileinfo.setSuffix(sourceFileinfo.getSuffix());
            }
        }
        fileinfoReposityInter.save(fileinfo);
        return AjaxReturnBean.createSuccess("文件信息保存成功",null);
    }
}
