package cn.sccin.spboot.web;

import cn.sccin.spboot.domain.Role;
import cn.sccin.spboot.domain.User;
import cn.sccin.spboot.domain.Userrole;
import cn.sccin.spboot.service.RoleService;
import cn.sccin.spboot.service.UserService;
import cn.sccin.spboot.utils.Statements;
import cn.sccin.spboot.web.pojo.AjaxReturnBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

/**
 * Created by developer_hyaci on 2015/9/24.
 */
@Controller
public class UserControl extends GlobalExcaptionHolder {
    /**
     * 人工干预强制登出，操作标识；
     * */
    public static final String PERSIONLOGINOUT="person_logout_flag";

    @Autowired
    private UserService userService;
    @Autowired
    private RoleService roleService;
    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @RequestMapping("/pub/register.html")
    public String register(@Param("username")String username,@Param("password") String password,Model model){
       if(username!=null &&!username.equals("")&&
                password!=null &&!password.equals("")){
            System.out.println(username + "<===>" + password);
            try {
                userService.register(username,password);
            }catch (Exception e){
                e.printStackTrace();
                model.addAttribute("error",true);
            }
        }
        return "register";
    }
    /**
     * 登录成功
     * @param request
     * @return
     */
    @RequestMapping("/loginSuccess.html")
    public String loginSuccess(HttpServletRequest request) {
        //登陆成功，可以执行一些处理；
        //User user=UserService.getUserFromSession(request);


        return "forward:/";
    }
    @RequestMapping(value={"/user/persionLogout"},method= RequestMethod.POST)
    public @ResponseBody AjaxReturnBean doPersionLogout(HttpServletRequest request,@Param("userId")String userId){
        User selectedUser=userService.findOne(userId);
        if(selectedUser.getFailnum()==99 || Statements.getLoginSessionMapSession(userId)!=null){
            //选中用户正登陆 或者 选中用户在服务端有维护登陆se    ssion;
            Statements.getLoginSessionMapSession(userId).setAttribute(PERSIONLOGINOUT, UserService.getUserFromSession(request));
            Statements.getLoginSessionMapSession(userId).invalidate();
            return AjaxReturnBean.createSuccess("用户登出成功",null);
        }else{
            return AjaxReturnBean.createError("当前操作用户未在登陆状态！",null);
        }
    }

    /***
     * 用户列表界面
     * @return
     */
    @RequestMapping("/user/paramsUser")
    public String userList(@PageableDefault(value = PAGESIZE) Pageable pageable, @Param("username") String username, Model model){
        Sort sort = new Sort(Sort.Direction.DESC, "flasttime");
        pageable = new PageRequest(pageable.getPageNumber(), pageable.getPageSize(), sort);
        Page<User> userPoerPage=userService.queryUserList(username,pageable);
        model.addAttribute("page",pageable.getPageNumber()+1);
        model.addAttribute("total",userPoerPage.getTotalPages());
        if(userPoerPage!=null && userPoerPage.getContent()!=null && userPoerPage.getContent().size()>0){
            model.addAttribute("users",userPoerPage.getContent());
        }else {
            model.addAttribute("users","");
        }
        model.addAttribute("username",username);
        return "user/userList";
    }

    @RequestMapping("/user/getRoleAdmins")
    public @ResponseBody
    AjaxReturnBean getAdmins(HttpServletRequest request){
        List<Role> listRole = roleService.queryAllRole();
        List<Map<String,String>> list = new ArrayList<Map<String,String>>();
        for (Role role : listRole) {
            Map<String,String> mapRole = new HashMap<String, String>();
            mapRole.put("frole", role.getCode());
            mapRole.put("frolename", role.getName());
            list.add(mapRole);
        }
        return AjaxReturnBean.createSuccess("",list);
    }

    @RequestMapping("/user/verifyUserFsyslname")
    public @ResponseBody AjaxReturnBean verifyUserFsyslname(@Param("fsyslname") String fsyslname,HttpServletRequest request){
        return AjaxReturnBean.createSuccess("",userService.verifyUserFsyslname(fsyslname));
    }

    /**
     * 根据fid获取用户信息
     * @param fid
     * @return
     */
    @RequestMapping(value = "/user/detailUser")
    public @ResponseBody AjaxReturnBean detailUser(HttpServletRequest request,@Param("fid") String fid) {
        String msg = "";
        boolean fidFlag = fid != null && !fid.trim().equals("");
        if (fidFlag) {
            User user = userService.detailUser(fid);
            return AjaxReturnBean.createSuccess("success",user);
        } else {
            return AjaxReturnBean.createError("用户唯一标识传递失败，请重新传递",null);
        }
    }

    @RequestMapping("/user/addUser")
    @ResponseBody
    public AjaxReturnBean addUser(@Param("id")String id,@Param("name")String name,@Param("loginName")String loginName,
                                        @Param("pasd")String pasd,@Param("role")String role,@Param("realname")String realname,
                                        @Param("email")String email,@Param("phone")String phone,@Param("ca")String ca,
                                      @Param("isvalid")String isvalid,@Param("savePsdFlag")String savePsdFlag){
        Map<String, Object> map = new HashMap<String, Object>();
        if("0".equals(savePsdFlag)){
            String reg = "^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,20}$";
            if(!pasd.matches(reg)){
               return AjaxReturnBean.createError("密码应由6-20位字母数字组成",null);
            }
        }
        String userId ="";
        List<Userrole> userrole = null;
        List<Role> list = new ArrayList<>();
        if(role!=null && !"".equals(role)){
            String[] arr = role.split("\\?");
            for(int i=0;i<arr.length;i++){
                Role role1 = roleService.querRoleByCode(arr[i]);
                list.add(role1);
            }
        }
        boolean flag = false;
        if(id!=null && !"".equals(id)){
            //修改
            userId = id;
            User u = userService.findOne(userId);
            if(u!=null){
                u.setName(name);
                u.setLoginame(loginName);
                if("0".equals(savePsdFlag)){
                    u.setPasd(this.passwordEncoder.encode(pasd));
                }
                u.setRealname(realname);
                u.setEmail(email);
                u.setPhone(phone);
                u.setCa(ca);
                u.setIsvalid(Integer.parseInt(isvalid));
                u.setIssys(1);
            }
            userrole = roleService.queryUserRoleByUserId(id);
            flag = userService.saveUser(u,list,userrole);
        }else{
            userId = UUID.randomUUID().toString();
            User u = new User();
            u.setId(userId);
            u.setName(name);
            u.setLoginame(loginName);
            u.setPasd(this.passwordEncoder.encode(pasd));
            u.setRealname(realname);
            u.setEmail(email);
            u.setPhone(phone);
            u.setCa(ca);
            u.setIsvalid(Integer.parseInt(isvalid));
            u.setIssys(1);
            u.setFailnum(0);
            flag = userService.saveUser(u,list,null);
        }
        if(flag){
            return AjaxReturnBean.createSuccess("",null);
        }else{
            return AjaxReturnBean.createError("新增失败",null);
        }
    }

    @RequestMapping("/user/delUser")
    @ResponseBody
    public AjaxReturnBean delUser(@Param("fid") String fid,HttpServletRequest request){
        //先判断是否能删除 目前不考虑
        boolean fidFlag = fid != null && !fid.trim().equals("");
        if (fidFlag){
            //先登出用户
            User selectedUser=userService.findOne(fid);
            if(selectedUser.getFailnum()==99 || Statements.getLoginSessionMapSession(fid)!=null){
                //选中用户正登陆 或者 选中用户在服务端有维护登陆se    ssion;
                Statements.getLoginSessionMapSession(fid).setAttribute(PERSIONLOGINOUT, UserService.getUserFromSession(request));
                Statements.getLoginSessionMapSession(fid).invalidate();
            }
            boolean flag = userService.delUser(fid);
            if(flag){
                return AjaxReturnBean.createSuccess("success",null);
            }else{
                return AjaxReturnBean.createError("用户删除失败，请重试",null);
            }
        }else{
            return AjaxReturnBean.createError("用户唯一标识传递失败，请重新传递",null);
        }
    }
}
