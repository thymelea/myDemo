package cn.sccin.spboot.service;

import cn.sccin.spboot.domain.Roleauths;
import cn.sccin.spboot.domain.repository.RoleReposityInter;
import cn.sccin.spboot.domain.repository.RoleauthsReposityInter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Component("roleauthsService")
public class RoleauthsService {
    private RoleauthsReposityInter roleauthsReposityInter;

    @Autowired
    public RoleauthsService(RoleauthsReposityInter roleauthsReposityInter){
        this.roleauthsReposityInter = roleauthsReposityInter;
    }

    //根据角色id,Code获取角色权限
    public List<Roleauths> findByRoleIdAndRoleCode(String roleId,String roleCode){
        return this.roleauthsReposityInter.findByRroleidAndCrolecode(roleId,roleCode);
    }

    /**
     * 保存设置的权限
     * roleId        角色唯一标识
     * roleCode      角色编码
     * auths         需要设置的权限
     */
    @Transactional
    public void modifyRoleAuths(String roleId,String roleCode,String[] auths){
        //根据角色唯一标识将该角色已经设置好的权限取出
        List<Roleauths> lstAuths = this.roleauthsReposityInter.findByRroleid(roleId);
        //删除权限后重新设置
        if(lstAuths!=null && lstAuths.size()>0){
            roleauthsReposityInter.delete(lstAuths);
        }

        //重新设置权限
        if(auths!=null&&auths.length>0){
            List<Roleauths> roleauthsList = new ArrayList<>();
            Roleauths roleauths = null;
            for(String s:auths){
                roleauths = new Roleauths();
                roleauths.setId(UUID.randomUUID().toString());
                roleauths.setRroleid(roleId);
                roleauths.setCrolecode(roleCode);
                roleauths.setRauthorityid(s);
                roleauthsList.add(roleauths);
            }
            if(roleauthsList.size()>0){
                roleauthsReposityInter.save(roleauthsList);
            }
        }
    }

    /**
     * 删除设置的权限
     * roleId        角色唯一标识
     */
    @Transactional
    public void delRoleAuths(String roleId){
        List<Roleauths> list = this.roleauthsReposityInter.findByRroleid(roleId);
        if(list!=null &&list.size()!=0){
            //删除已经存在的数据
            roleauthsReposityInter.delete(list);
        }
    }

    //查询已经授权的角色
    public Page<Roleauths> queryRoleauthsByParams(String roleName, String roleCode, Pageable pageable){
        boolean roleNameFlag = roleName != null && !roleName.trim().equals("");
        boolean roleFlag = roleCode != null && !roleCode.trim().equals("");
        Page<Roleauths> roleAuthsPage=null;
        if(roleFlag && roleNameFlag){
            roleAuthsPage = roleauthsReposityInter.queryRoleauthsPage(pageable,roleCode,roleName);
        }else if(roleFlag){
            roleAuthsPage = roleauthsReposityInter.queryRoleauthsByRoleCodePage(pageable,roleCode);
        }else if(roleNameFlag){
            roleAuthsPage = roleauthsReposityInter.queryRoleauthsByRoleNmPage(pageable,roleName);
        }else{
            roleAuthsPage = roleauthsReposityInter.queryRoleauthsPage(pageable);
        }
        return roleAuthsPage;
    }


    //根据角色ID获取权限
    public List<Roleauths> findByRoleId(String roleId){
        if(roleId==null||roleId.trim().equals("")){
            return new ArrayList<>();
        }else{
            return roleauthsReposityInter.findByRroleid(roleId);
        }
    }
}
