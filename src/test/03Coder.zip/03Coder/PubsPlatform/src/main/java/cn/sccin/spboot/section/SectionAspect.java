package cn.sccin.spboot.section;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.boot.context.web.OrderedCharacterEncodingFilter;
import org.springframework.boot.context.web.OrderedHiddenHttpMethodFilter;
import org.springframework.boot.context.web.OrderedHttpPutFormContentFilter;
import org.springframework.boot.context.web.OrderedRequestContextFilter;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.web.servletapi.SecurityContextHolderAwareRequestFilter;
import org.springframework.security.web.servletapi.SecurityContextHolderAwareRequestWrapper;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by developer_hyaci on 2017/6/27.
 */
//@Aspect
//@Configuration
public class SectionAspect {
    // 定义切点Pointcut
//    @Pointcut("execution(* cn.sccin.spboot.web.thirdparty.RecvFreeBackController.receiveCCBfeedback(..))")
//    @Pointcut("execution(* cn.sccin.spboot.web..*(..)) and @annotation(org.springframework.web.bind.annotation.RequestMapping")
    public void ccbFeedBack() {}

//    @Around("ccbFeedBack()")
    public void aroundCcbFeedBack(ProceedingJoinPoint pjp) throws Throwable{
        RequestAttributes ra = RequestContextHolder.getRequestAttributes();
        ServletRequestAttributes sra = (ServletRequestAttributes) ra;
        HttpServletRequest request = sra.getRequest();

        /*SecurityContextHolderAwareRequestFilter
        SecurityContextHolderAwareRequestWrapper*/

        //方法执行前；
        Object o=pjp.proceed();
        //方法执行后；
        //o 方法执行之后返回的结果集

    }

}
