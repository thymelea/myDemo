package cn.sccin.spboot.service;

import cn.sccin.spboot.domain.Role;
import cn.sccin.spboot.domain.repository.RoleReposityInter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import cn.sccin.spboot.domain.Userrole;
import cn.sccin.spboot.domain.repository.UserRoleReposityInter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Component("roleService")
public class RoleService {
    @Autowired
    private RoleReposityInter roleReposityInter;
    @Autowired
    private UserRoleReposityInter userRoleReposityInter;

    public List<Role> queryAllRole(){
        return roleReposityInter.findAll();
    }

    public Role querRoleByCode(String code){
        return roleReposityInter.queryRoleByCode(code);
    }

    public List<Userrole> queryUserRoleByUserId(String userId){
        return userRoleReposityInter.queryRoleByCode(userId);
    }

    //根据角色唯一标识获取用户角色绑定详情
    public List<Userrole> findUserroleByRoleId(String roleId){
        return this.userRoleReposityInter.findByRroleid(roleId);
    }


    //根据角色名称获取角色
    public Page<Role> findRole(String roleNm,Pageable pageable){
        boolean roleFlag = roleNm != null && !roleNm.trim().equals("");
        Page<Role> rolePage=null;
        if(roleFlag){
            rolePage = roleReposityInter.queryRolePage(pageable, roleNm);
        }else{
            rolePage = roleReposityInter.findAll(pageable);
        }
        return rolePage;
    }


    //根据角色CODE获取角色
    public Role findByRoleCode(String roleCode){
        return roleReposityInter.findByCode(roleCode);
    }

    //根据角色唯一标识（fid）获取角色
    public Role findByFid(String fid){
        return roleReposityInter.findOne(fid);
    }


    //设置权限前获取角色
    public List<Role> findByRoleId(String roleId){
        List<Role> listRoles = new ArrayList<>();
        if(roleId != null && !roleId.trim().equals("")){
            listRoles.add(roleReposityInter.getOne(roleId));
        }else{
            listRoles = roleReposityInter.findAll();
        }
        return listRoles;
    }

    /** 入库*/
    @Transactional
    public void saveRole(Role role){
        roleReposityInter.save(role);
    }

    /** 删除*/
    @Transactional
    public void deleteRole(Role role){
        roleReposityInter.delete(role);
    }
}
