package cn.sccin.spboot.domain.repository;

import cn.sccin.spboot.domain.User;
import cn.sccin.spboot.domain.specific.UserDao;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.thymeleaf.standard.expression.Each;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.*;

/**
 * Created by developer_hyaci on 2017/4/10.
 */
public class UserReposityInterImpl implements UserDao {

    @PersistenceContext
    private EntityManager entityManager;

    /*public Page<SysUser> search(Map<String,String> params){
        StringBuilder sqlBuilder=new StringBuilder();
        sqlBuilder.append("SELECT * FROM TUSER WHERE 1=1 ");
        if(params.containsKey("name_like")&&params.get("name_like")!=null&&
                !params.get("name_like").equals("")){
            sqlBuilder.append("AND FUSERNAME LIKE '%"+params.get("name_like")+"%' ");
        }

        if(params.containsKey("logiName_eq")&&params.get("logiName_eq")!=null&&
                !params.get("logiName_eq").equals("")){
            sqlBuilder.append("AND FSYSLNAME ='"+params.get("logiName_eq")+"' ");
        }
        javax.persistence.Query query = entityManager.createNativeQuery(sqlBuilder.toString());
        return new PageImpl<SysUser>(query.getResultList());
    }*/

    @Override
    public List<Map<String, String>> getRefundInfos(List<String> refunds) {
        StringBuilder sb=new StringBuilder();
        sb.append("SELECT DISTINCT(ex.FTRADEUNIQUE),refund.FREFUNDID,ex.FPBUCODE,refund.FEXPAND,ex.FTYPE " +
                "FROM trefund refund INNER JOIN texchangerecords ex on ex.FID=refund.FEXCHANGEID " +
                "WHERE refund.FSTATUS='7' AND ex.FTYPE IN ('22','23','40') ");
        if(refunds!=null && refunds.size()!=0){
            StringBuilder inStr=new StringBuilder();
            refunds.stream().forEach(str->{
                if(!inStr.toString().equals("")){
                    inStr.append(",'"+str+"'");
                }else{
                    inStr.append("'"+str+"'");
                }
            });
            sb.append("AND refund.FREFUNDID IN ("+inStr.toString()+") ");
        }
        sb.append("ORDER BY refund.FREFUNDID LIMIT 100 ");
        javax.persistence.Query query = entityManager.createNativeQuery(sb.toString());
        List<Object []> objs = query.getResultList();
        if(objs!=null && objs.size()!=0){
            List<Map<String,String>> resultList=new ArrayList<>();
            Map<String,String> emptyMap=null;
            String orderNo="";
            String refundNo="";
            String type="";
            String expend="";
            for(int i=0;i<objs.size();i++){
                emptyMap=new HashMap<>();
                refundNo=objs.get(i)[1] != null ? objs.get(i)[1].toString() : "";
                orderNo=objs.get(i)[0] != null ? objs.get(i)[0].toString() : "";
                type=objs.get(i)[4] != null ? objs.get(i)[4].toString() : "";
                expend=objs.get(i)[3] != null ? objs.get(i)[3].toString() : "";
                emptyMap.put("refundNo",refundNo);
                emptyMap.put("fpbucode",objs.get(i)[2] != null ? objs.get(i)[2].toString() : "");
                //当制单号与订单号一样且是R开头且FTYPE 为40 时表示当前为未使用流水制单，订单号的获取方式将从expend中获取
                if(!refundNo.equals("")&&refundNo.equals(orderNo)&&refundNo.startsWith("R")&&type.equals("40")){
                        if(!expend.equals("")){
                            String [] strs=expend.split(",");
                            for(String str:strs){
                                if(str.indexOf("unsedOrderId")!=-1){
                                    String[] itemStrs=str.split(":");
                                    emptyMap.put("orderNo",itemStrs[1]);
                                    break;
                                }
                            }
                        }else{
                            emptyMap.put("orderNo","");
                        }
                }else{
                    emptyMap.put("orderNo",orderNo);
                }
                resultList.add(emptyMap);
            }
            return  resultList;
        }
        return null;
    }

    @Override
    public Page<User> queryUserList(String userName, Pageable pageable) {
        StringBuilder sb= new StringBuilder();
        sb.append("SELECT t1.fid id,t1.floginame loginName,t1.fname fname,t1.femail email, ");
        sb.append(" t1.fisvalid isUse from etuser t1 ");
        sb.append(" WHERE 1=1 ");
        if(userName!=null && !"".equals(userName.trim())){
            sb.append(" and t1.fname like :userName ");
        }
        javax.persistence.Query query = entityManager.createNativeQuery(sb.toString());
        if(userName!=null && !"".equals(userName.trim())){
            query.setParameter("userName","%"+userName+"%");
        }
        List<Object []> objs = query.getResultList();
        try{
            List<User> list = new ArrayList<>();
            int total = objs.size();
            if(objs!=null && total>0){
                for(int i=0;i<objs.size();i++){
                    Object[] o = objs.get(i);
                    /*StringBuilder csb = new StringBuilder();
                    String roleName = "";
                    csb.append("SELECT t1.fname FROM etrole t1 LEFT JOIN rnuserrole t2 ON t1.fid = t2.rroleid where t2.ruserid = '"+o[0].toString()+"'");
                    javax.persistence.Query cquery = entityManager.createNativeQuery(csb.toString());
                    List<Object []> cobjs = cquery.getResultList();
                    if(cobjs!=null && cobjs.size()>0){
                        for(int j=0;j<cobjs.size();j++){
                            Object co = cobjs.get(j);
                            roleName += co.toString() + ",";
                        }
                    }*/
                    String id = (String)o[0];
                    String loginName = (String)o[1];
                    String name = (String)o[2];
                    String email = (String)o[3];
                    Integer isUse = (Integer) o[4];
                    User u = new User();
                    u.setId(id);
                    u.setLoginame(loginName);
                    u.setName(name);
                    u.setEmail(email);
                    /*if(roleName!=null && !"".equals(roleName)){
                        u.setRoleName(roleName.substring(0,roleName.length()-1));
                    }*/
                    u.setIsvalid(isUse);
                    list.add(u);
                }
            }
            objs = null;
            return new PageImpl<>(list,pageable,total);
        }catch (Exception e){
            return null;
        }
    }

    @Override
    public Map<String, String> queryRoleNames(List<String> userIdList) {
        Map<String,String> result = new HashMap<>();
        StringBuilder sb = new StringBuilder();
        sb.append(" SELECT t2.ruserid, t1.fname FROM etrole t1 LEFT JOIN rnuserrole t2 ON t1.fid = t2.rroleid where t2.ruserid in :userIdList ");
        javax.persistence.Query cquery = entityManager.createNativeQuery(sb.toString());
        cquery.setParameter("userIdList",userIdList);
        List<Object []> objs = cquery.getResultList();
        if(objs!=null&& objs.size()>0){
            for(int i=0;i<objs.size();i++){
                Object[] o = objs.get(i);
                String id = (String)o[0];
                String fname = (String)o[1];
                if(result.containsKey(id)){
                    String roleName = result.get(id).toString();
                    roleName = roleName+fname+",";
                    result.put(id,roleName);
                }else{
                    result.put(id,fname+",");
                }
            }
        }
        return result;
    }

    @Override
    public User findUserById(String userId) {
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT t1.fid id,t1.floginame loginName,t1.fname fname,t1.femail email, ");
        sb.append(" t1.fisvalid isUse,t1.fpasd pasd,t1.fphone phone,t1.fca ca ,t1.fissys issys,t1.frealname realname from etuser t1 ");
        sb.append(" WHERE t1.fid = :userId ");
        javax.persistence.Query query = entityManager.createNativeQuery(sb.toString());
        query.setParameter("userId",userId);
        List<Object []> objs = query.getResultList();
        try{
            User u =new User();
            int total = objs.size();
            if(objs!=null && total>0){
                for(int i=0;i<objs.size();i++){
                    Object[] o = objs.get(i);
                    StringBuilder csb = new StringBuilder();
                    String roleName = "";
                    csb.append("SELECT t1.fcode FROM etrole t1 LEFT JOIN rnuserrole t2 ON t1.fid = t2.rroleid where t2.ruserid = :userId");
                    javax.persistence.Query cquery = entityManager.createNativeQuery(csb.toString());
                    cquery.setParameter("userId",userId);
                    List<Object []> cobjs = cquery.getResultList();
                    if(cobjs!=null && cobjs.size()>0){
                        for(int j=0;j<cobjs.size();j++){
                            Object co = cobjs.get(j);
                            roleName += co.toString() + ",";
                        }
                    }
                    String id = (String)o[0];
                    String loginName = (String)o[1];
                    String name = (String)o[2];
                    String email = (String)o[3];
                    Integer isUse = (Integer) o[4];
                    String pasd = (String)o[5];
                    String phone =(String)o[6];
                    String ca = (String)o[7];
                    Integer issys = (Integer)o[8];
                    String realname = (String)o[9];
                    u.setId(id);
                    u.setLoginame(loginName);
                    u.setName(name);
                    u.setEmail(email);
                    if(roleName!=null && !"".equals(roleName)){
                        u.setRoleName(roleName.substring(0,roleName.length()-1));
                    }
                    u.setIsvalid(isUse);
                    u.setPasd(pasd);
                    u.setPhone(phone);
                    u.setCa(ca);
                    u.setIssys(issys);
                    u.setRealname(realname);
                }
            }
            objs = null;
            return u;
        }catch (Exception e){
            return null;
        }
    }

    @Override
    public List<User> getUserByParams(String userName, String uerloginName) {
        StringBuffer sb=new StringBuffer();
        sb.append("SELECT * FROM etuser U WHERE 1=1 ");
        if(uerloginName!=null && !uerloginName.trim().equals("")){
            sb.append("and U.floginame LIKE :loginName ");
        }
        if(userName!=null && !userName.trim().equals("")){
            sb.append("AND U.fname LIKE :userName ");
        }
        Query query = this.entityManager.createNativeQuery(sb.toString());

        if(userName!=null && !userName.trim().equals("")){
            query.setParameter("userName", "%"+userName+"%");
        }
        if(uerloginName!=null && !uerloginName.trim().equals("")){
            query.setParameter("loginName","%"+uerloginName+"%");
        }
        List<User> resultUser = query.getResultList();
        return resultUser;
    }
}
