package cn.sccin.spboot.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by developer_hyaci on 2016/6/30.
 * controller global handle excaption!
 */
public class GlobalExcaptionHolder {


    private final static Logger logger = LoggerFactory.getLogger(GlobalExcaptionHolder.class);
    // 默认每页显示20条数据
    public final static int PAGESIZE = 20;
    @ExceptionHandler
    public String exp(HttpServletRequest request, Exception ex) {
        String path=request.getServletPath();
        StringBuffer vistiParams=new StringBuffer();
        if(request.getParameterMap()!=null){
            for(String key:request.getParameterMap().keySet()){
                if(vistiParams.length()>0){
                    vistiParams.append("|"+key+":"+request.getParameterMap().get(key)[0].toString());
                }else{
                    vistiParams.append(key+":"+request.getParameterMap().get(key)[0].toString());
                }
            }
        }
        String uuid=System.currentTimeMillis()+"";
        logger.error("["+uuid+"] visit path[" + path + "] been exception:" + ex.getMessage()+ (vistiParams.length()>0?(",with params:" + vistiParams.toString()):""));
        request.setAttribute("errorUnique",uuid);
        return "error";
    }


}
