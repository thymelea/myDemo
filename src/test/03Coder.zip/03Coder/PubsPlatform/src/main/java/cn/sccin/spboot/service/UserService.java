package cn.sccin.spboot.service;

//import cn.sccin.spboot.domain.repository.SysUserReposity;
import cn.sccin.spboot.domain.Authority;
import cn.sccin.spboot.domain.Role;
import cn.sccin.spboot.domain.User;
import cn.sccin.spboot.domain.repository.AuthorityReposityInter;
import cn.sccin.spboot.domain.Userrole;
import cn.sccin.spboot.domain.repository.UserReposityInter;
import cn.sccin.spboot.domain.repository.UserRoleReposityInter;
import cn.sccin.spboot.security.DefineAuthItem;
import cn.sccin.spboot.security.SecurityUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.StandardPasswordEncoder;
import org.springframework.stereotype.Component;
        import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

/**
 * Created by developer_hyaci on 2015/9/24.
 */
@Component("userService")
public class UserService {

    /**
     * 采用SPRING SECURITY 之后，当前登陆用户会储存在SESSION里面
     * 该方法为获取当前登陆的用户；
     * @return bean|null
     * */
    public static User getUserFromSession(HttpServletRequest request){
        User user =null;
        if(request.getSession().getAttribute("SPRING_SECURITY_CONTEXT")!=null){
            SecurityContext securityContext= (SecurityContextImpl)request.getSession().getAttribute("SPRING_SECURITY_CONTEXT");
            Authentication auth=securityContext.getAuthentication();
            user=((SecurityUser)auth.getPrincipal()).getLoginUser();
        }
        return user;
    }
    /**
     * 采用SPRING SECURITY 之后，当前登陆用户会储存在SESSION里面
     * 该方法为获取当前登陆的用户的权限；
     * @return bean|null
     **/
    public static ArrayList<DefineAuthItem> getUserAuthsTreeFromSession(HttpServletRequest request){
        ArrayList<DefineAuthItem> auths =null;
        if(request.getSession().getAttribute("SPRING_SECURITY_CONTEXT")!=null){
            SecurityContext securityContext= (SecurityContextImpl)request.getSession().getAttribute("SPRING_SECURITY_CONTEXT");
            Authentication auth=securityContext.getAuthentication();
            auths=((SecurityUser)auth.getPrincipal()).getAuthsTree();
        }
        return auths;
    }

    @Autowired
    private UserReposityInter userReposity;
    @Autowired
    private AuthorityReposityInter authorityReposityInter;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;
    @Autowired
    private UserRoleReposityInter userRoleReposityInter;
    @Autowired
    private  RoleService roleService;

    /**
     * 应用启动之初，将处于登陆状态的用户重置为未登陆
     */
    @Transactional
    public void initUserStateUseforStartUp(){
        userReposity.initUserLoginStateAtStartUp();
    }
    /**
     *获取某个用户的权限
     */
    public List<Authority> getUserAuths(String userId){
        return  authorityReposityInter.getUserAhthoritys(userId);
    }



    public void register(String userName,String psd){
        User user=new User();
        user.setId(UUID.randomUUID().toString());
        user.setLoginame(userName);
        user.setPasd(this.passwordEncoder.encode(psd));
        user.setIsvalid(1);
        userReposity.save(user);
//        SysRole role = roleReposity.findByFrolecode("ADMIN");
//        RUserRole userRole=new RUserRole();
//        userRole.setFid(UUID.randomUUID().toString());
//        userRole.setFroleid(role.getFid());
//        userRole.setFuserid(user.getFid());
//        userRoleReposity.save(userRole);

    }

    public User detailUser(String fid){
        return userReposity.findUserById(fid);
    }

    public User findOne(String fid){
        return userReposity.findOne(fid);
    }

    public Page<User> queryUserList(String userName, Pageable pageable){
        Page<User> userPage = userReposity.queryUserList(userName,pageable);
        if(userPage!=null && userPage.getContent()!=null && userPage.getContent().size()>0){
            StringBuilder sb = new StringBuilder();
            List<String> userIdList = new ArrayList<>();
            for(User u:userPage.getContent()){
                userIdList.add(u.getId());
            }
            Map<String,String> result = userReposity.queryRoleNames(userIdList);
            if(result!=null){
                for(User u:userPage.getContent()){
                    String roleNames = result.get(u.getId());
                    if(roleNames!=null && !"".equals(roleNames)){
                        u.setRoleName(roleNames.substring(0,roleNames.length()-1));
                    }
                }
            }
        }
        return userPage;
    }

    public String verifyUserFsyslname(String fsyslname){
        User user = userReposity.findByLoginame(fsyslname);
        String msg = "";
        if (user != null && !user.toString().equals("")) {
            msg = "该登录名已存在";
        } else{
            msg = "success";
        }
        return msg;
    }

    @Transactional
    public boolean saveUser(User user,List<Role> role,List<Userrole> userrole){
        if(role!=null ){
            if(userrole!=null){
                userRoleReposityInter.delete(userrole);
            }
            List<Userrole> saveList = new ArrayList<>();
            if(role.size()>0){
                for(Role r:role){
                    Userrole ur = new Userrole();
                    String roleid = r.getId();
                    String rolecode = r.getCode();
                    ur.setId(UUID.randomUUID().toString());
                    ur.setRuserid(user.getId());
                    ur.setCrolecode(rolecode);
                    ur.setRroleid(roleid);
                    saveList.add(ur);
                }
            }
            userReposity.save(user);
            userRoleReposityInter.save(saveList);
            return true;
        }else{
            return false;
        }
    }

    @Transactional
    public boolean delUser(String userId){
        List<Userrole> userrole = roleService.queryUserRoleByUserId(userId);
        if(userrole!=null){
            userReposity.delete(userId);
            userRoleReposityInter.delete(userrole);
            return true;
        }else {
            return false;
        }
    }

}
