package cn.sccin.spboot.web;

import cn.sccin.spboot.domain.Role;
import cn.sccin.spboot.domain.Roleauths;
import cn.sccin.spboot.service.AuthorityService;
import cn.sccin.spboot.service.RoleService;
import cn.sccin.spboot.service.RoleauthsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.query.Param;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
///┍┒      ┍┒
//┍┛┷━   ━━┛┷┓
//┃          ┃
//┃     ━    ┃
//┃  ┳┛  ┗┳  ┃
//┃          ┃
//┃    ┷     ┃
//┃          ┃
//┗━┓      ┏━┛
//  ┃      ┃神兽保佑
//  ┃      ┃代码无BUG！
//  ┃      ┗━━━┓
//  ┃          ┃
//  ┃          ┣┓
//  ┃          ┏┛
//  ┗┓┓┏━   ┳┓┏┛
//   ┃┫┫    ┃┫┫
//   ┗┷┛    ┗┷┛
@Controller
public class RoleauthsControl extends GlobalExcaptionHolder{

    @Autowired
    private RoleauthsService roleauthsService;
    @Autowired
    private RoleService roleService;
    @Autowired
    private AuthorityService authorityService;

     //设置权限
     @RequestMapping(value = "/role/roleAuthsSetting.html")
     public String roleAuthsSetting(@Param("roleId")String roleId,Model model){
         //根据角色ID获取角色
         List<Role> rols = roleService.findByRoleId(roleId);
         List<Map<String,String>> mapList_roles = rols.stream().filter(role->{
             if(role.getCode().equals("ADMIN")){
                 return false;
             }
             return true;
         }).map(role->{
             Map<String, String> map = new HashMap<String, String>();
             map.put("roleId", role.getId());
             map.put("roleName", role.getName());
             map.put("roleCode", role.getCode());
             return map;
         }).collect(Collectors.toList());;

         //获取该角色已有权限
         List<Roleauths> roleauths = roleauthsService.findByRoleId(roleId);
         List<Map<String,Object>> authList_map=authorityService.changToListMap(authorityService.getAutoritys(), roleauths);

         //获取所有的后台权限
         List<Map<String,Object>> backAuths= authList_map.stream().filter(map -> {
             return map.get("auType").toString().equals("1");
         }).sorted((map1,map2)->{
             return ((Integer)map1.get("index")).compareTo((Integer) map2.get("index"));
         }).collect(Collectors.toList());

         //获取所有的前台权限
         List<Map<String,Object>> preAuths= authList_map.stream().filter(map -> {
             return map.get("auType").toString().equals("2");
         }).sorted((map1,map2)->{
             return ((Integer)map1.get("index")).compareTo((Integer) map2.get("index"));
         }).collect(Collectors.toList());

         model.addAttribute("roles",mapList_roles);
         model.addAttribute("roleSize", mapList_roles.size());
         /*model.addAttribute("busystems",mapList_visitCfgs);
         model.addAttribute("busysSize",mapList_visitCfgs.size());*/

         model.addAttribute("preHide","0");
         if(mapList_roles.size()==1){
             if(mapList_roles.get(0).get("roleCode").indexOf("ADMIN")!=-1){
                 model.addAttribute("preHide","1");
             }
         }
         model.addAttribute("backAuths",backAuths);
         model.addAttribute("preAuths",preAuths);

         return "role/roleAuthsSetting";
     }


     //保存设置的权限
     @RequestMapping(value = "/role/roleAuthsModify")
     public String modifyRolePower(@Param("roleId")String roleId,@Param("roleCode")String roleCode,@Param("auths")String [] auths){
         try{
             roleauthsService.modifyRoleAuths(roleId,roleCode,auths);
         }catch (Exception e){
             //抛出全局Exeception....
         }
         return "redirect:/role/paramsRole.html";
     }

}
