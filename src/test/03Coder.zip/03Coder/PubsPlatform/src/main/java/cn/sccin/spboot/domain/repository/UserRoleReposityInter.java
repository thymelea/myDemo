package cn.sccin.spboot.domain.repository;

import cn.sccin.spboot.domain.Role;
import cn.sccin.spboot.domain.Userrole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Created by yx on 2017/10/18.
 */
public interface UserRoleReposityInter extends JpaRepository<Userrole,String>, JpaSpecificationExecutor<Userrole> {

    @Query("select r FROM Userrole r where r.ruserid =:userId ")
    List<Userrole> queryRoleByCode(@Param("userId")String userId);

    List<Userrole> findByRroleid(String roleId);
}
