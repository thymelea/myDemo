package cn.sccin.spboot.security;

import cn.sccin.spboot.config.SysConfig;
import cn.sccin.spboot.domain.Authority;
import cn.sccin.spboot.domain.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.time.LocalDateTime;
import java.util.*;

public class SecurityUser implements UserDetails {

	private static final long serialVersionUID = -2850148622557170441L;

	private User loginUser;

	@Autowired
	private SysConfig sysConfig;

	private static ArrayList<DefineAuthItem> authsTree=new ArrayList<>();

	private List<Authority> auths;


	public SecurityUser(User user){
		this.loginUser=user;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
		//构造平台权限
		ArrayList<GrantedAuthority> builder=new ArrayList<>();
		if(auths!=null && auths.size()!=0){
			for(int i=0;i<auths.size();i++){
				builder.add(new DefineAuthItem(auths.get(i)));
			}
		}
		return builder;
	}

	public void qrySubByAuthItem(DefineAuthItem authItem){
		for(int i=0;i<auths.size();i++){
			if(auths.get(i).getParent()!=null
					&& !(auths.get(i).getParent().equals(""))
					&& auths.get(i).getParent().equals(authItem.getAuthorityBean().getId())){
				DefineAuthItem sub=new DefineAuthItem(auths.get(i));
				this.qrySubByAuthItem(sub);
				authItem.getSubAuth().add(sub);
			}
		}
	}

	public ArrayList<DefineAuthItem> getAuthsTree() {
		if(authsTree.isEmpty()){
			if(auths!=null && auths.size()!=0){
				for(int i=0;i<auths.size();i++){
					//url 为0，type为表示后台顶级菜单
					if(auths.get(i).getUrl().equals("0") &&
							auths.get(i).getType().intValue()==1){
						DefineAuthItem	authItem=new DefineAuthItem(auths.get(i));
						qrySubByAuthItem(authItem);
						authsTree.add(authItem);
					}
				}
			}
		}
		return authsTree;
	}

	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return this.loginUser.getPasd();
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return this.loginUser.getName();
	}

	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		//账户是否已经登陆
		if(this.loginUser.getFailnum().intValue()==99){
			return false;
		}
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		//当前登陆用户登陆失败次数>10次，则半个小时不再允许再登陆
		if(this.loginUser.getFailnum().intValue()==10){
			LocalDateTime loclDateTime=this.loginUser.getLogtime().toLocalDateTime();
			String lockedTime = sysConfig.getAcountLockedTime();
			int lockedTimeIntValue = 30;
			if(lockedTime!=null && !lockedTime.trim().equals("") && !lockedTime.trim().equals("0")){
				lockedTimeIntValue=Integer.parseInt(lockedTime);
			}
			loclDateTime=loclDateTime.plusMinutes(lockedTimeIntValue);
			LocalDateTime now=LocalDateTime.now();
			if(now.compareTo(loclDateTime) < 0){
				return  false;
			}else{
				return  true;
			}
		}
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		//证书？
		return true;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		//当前登陆用户是否可用
		return this.loginUser.getIsvalid().intValue()==1?true:false;
	}

	public User getLoginUser() {
		return loginUser;
	}

	public String getCADN(){
		return loginUser.getCa();
	}

	public void setAuths(List<Authority> auths) {
		this.auths = auths;
	}

}
