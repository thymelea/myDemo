package cn.sccin.spboot.security;

import cn.sccin.spboot.domain.User;
import cn.sccin.spboot.service.LogsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;

/**
 * Created by developer_hyaci on 2016/3/17.
 */
@Component
public class LoginFailHandler extends SimpleUrlAuthenticationFailureHandler {
    @Autowired
    private LoginUserDetailsService userService;
    @Autowired
    private LogsService logService;

    @Override
    public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException exception) throws IOException, ServletException {
        this.setDefaultFailureUrl("/index.html");
        this.setUseForward(true);
        request.setAttribute("error",exception.getMessage());
        if(exception.getMessage().indexOf("User account has expired")!=-1){
            request.setAttribute("error","用户已在其他地方登陆！");
        }else if(exception.getMessage().indexOf("User account is locked")!=-1){
            request.setAttribute("error","您已经登陆失败10次，本账户将被锁定30分钟！");
        }else if(exception.getMessage().indexOf("Bad credentials")!=-1){
            request.setAttribute("error","用户名错误！");
        }else if(exception.getMessage().indexOf("User is disabled")!=-1){
            request.setAttribute("error","用户不可用！");
        }else{
            //用户名正确，但由于其他原因登陆失败，记录登陆失败次数；
            String userName=request.getSession().getAttribute(LoginFormParamFilter.UNVERIFYLOGINAME).toString();
            User user=  userService.getUserByUsername(userName);
            user.setFailnum(user.getFailnum().intValue()+1);
            user.setLogtime(Timestamp.valueOf(LocalDateTime.now()));
            userService.modifyUser(user);
            //记录登陆失败日志；
            logService.logInfo(this.getClass(),0,user.getLoginame(),user.getName(),"","","登陆失败"+user.getFailnum().intValue()+"次","登陆失败"+user.getFailnum().intValue()+"次",true);
        }
        super.onAuthenticationFailure(request, response, exception);
    }
}
