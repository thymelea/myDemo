package cn.sccin.spboot.domain.repository;

import cn.sccin.spboot.domain.Role;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface RoleReposityInter extends JpaRepository<Role,String>, JpaSpecificationExecutor<Role> {
    @Query("select r FROM Role r where r.code =:code ")
    Role queryRoleByCode(@Param("code")String code);

    Role findByCode(String roleCode);

    @Query("select r FROM Role r where r.name =:roleNm ")
    Page<Role> queryRolePage(Pageable pageable, @Param("roleNm")String roleNm);
}
