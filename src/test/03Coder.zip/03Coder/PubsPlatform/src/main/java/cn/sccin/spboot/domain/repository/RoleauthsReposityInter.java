package cn.sccin.spboot.domain.repository;

import cn.sccin.spboot.domain.Roleauths;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface RoleauthsReposityInter extends JpaRepository<Roleauths,String>, JpaSpecificationExecutor<Roleauths> {
    List<Roleauths> findByRroleidAndCrolecode(String roleId,String roleCode);

    List<Roleauths> findByRroleid(String roleId);

    //角色授权--------------start
    @Query("select distinct new Roleauths(ro.rroleid,ro.crolecode,r.name) " +
            "from Role r ,Roleauths ro " +
            "where r.id = ro.rroleid ")
    Page<Roleauths> queryRoleauthsPage(Pageable pageable);

    @Query("select distinct new Roleauths(ro.rroleid,ro.crolecode,r.name) " +
            "from Role r ,Roleauths ro " +
            "where r.id = ro.rroleid and ro.crolecode =:roleCode and r.name =:roleNm")
    Page<Roleauths> queryRoleauthsPage(Pageable pageable,@Param("roleCode")String roleCode,@Param("roleNm")String roleNm);

    @Query("select distinct new Roleauths(ro.rroleid,ro.crolecode,r.name) " +
            "from Role r ,Roleauths ro " +
            "where r.id = ro.rroleid and ro.crolecode =:roleCode ")
    Page<Roleauths> queryRoleauthsByRoleCodePage(Pageable pageable,@Param("roleCode")String roleCode);

    @Query("select distinct new Roleauths(ro.rroleid,ro.crolecode,r.name) " +
            "from Role r ,Roleauths ro " +
            "where r.id = ro.rroleid and r.name =:roleNm ")
    Page<Roleauths> queryRoleauthsByRoleNmPage(Pageable pageable,@Param("roleNm")String roleNm);
    //角色授权--------------end
}
