﻿//初始化证书 控件加载证书数据
var calist;

function innerCA(comboxid) {
    try {
        
        var ocx = document.getElementById("ocx");
        var s = ocx.GetAllCertificate();
        //获取证书列

        calist = eval("(" + s + ")");//转换为json对象 

        for (var i = 0; i < calist.length; i++) {
            if (i > 0) {
                if (calist[i] != null && calist[i] != "") {
                    $("#" + comboxid).append("<option value='" + calist[i].CertificateDn + "'>" + calist[i].CertificateDn.split(',')[0].split('=')[1] + "</option>");
                }
            } else {
                $("#" + comboxid).append("<option  selected = \"selected\" value='" + calist[i].CertificateDn + "'>" + calist[i].CertificateDn.split(',')[0].split('=')[1] + "</option>");
            }
        }
        
    } catch (e) {
       // window.open("/Files/setup.rar", "_blank", "");

    } 
   
}


function GetCAData() {
    try {
        var ocx = document.getElementById("ocx");
        if (ocx != null) {
            var s = ocx.GetAllCertificate();
            //获取证书列

            calist = eval("(" + s + ")");//转换为json对象 
            return calist;
        }
    } catch (e) {
       // window.open("/Files/setup.rar", "_blank", "");
    }
}




//读取开始时间

function GetCaBeginDate(ca) {

    if (ca != '') {
        var date = SearchCa(ca).StartTime.split('T')[0];
        var time = SearchCa(ca).StartTime.split('T')[1].split(':');
        return date + ' ' + time[0] + ':' + time[1];
    }

}

//读取结束时间
function GetCaEndDate(ca) {
    if (ca != '') {
        var date = SearchCa(ca).Deadline.split('T')[0];
        var time = SearchCa(ca).Deadline.split('T')[1].split(':');
        return date + ' ' + time[0] + ':' + time[1];
    }
}

//查询ca对象
function SearchCa(ca) {

    if (calist != null && calist.length != 1) {
        for (var i = 0; i < calist.length; i++) {
            if (calist[i].CertificateDn == ca) {
                return calist[i];
            }
             
        }
        return null;
    }
    else if (calist.length == 1) {
        return calist[0];

    } else {
        return null;
    }
}